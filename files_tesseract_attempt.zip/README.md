# Screen Value Extractor for MCS Measurement System

Python application to automatically detect and extract measurement values from the Chinese Windows 7 MCS measurement system. Detects green-background value boxes and extracts the numerical values using OCR.

## Features

✅ **Automatic Detection**: Detects green value boxes automatically  
✅ **OCR Extraction**: Extracts numerical values using Tesseract OCR  
✅ **Multiple Modes**: Single capture, continuous monitoring, and GUI interface  
✅ **Data Logging**: Saves results to CSV and JSON formats  
✅ **Debug Mode**: Visual debugging with annotated screenshots  
✅ **Real-time Monitoring**: Continuous value extraction at configurable intervals

## Files Included

1. **value_extractor.py** - Basic command-line version with debug capabilities
2. **value_extractor_gui.py** - Full GUI application with real-time monitoring
3. **mcs_value_extractor.py** - Optimized version specifically for MCS system
4. **requirements.txt** - Python package dependencies

## Installation

### Step 1: Install Python

Download and install Python 3.8 or higher from [python.org](https://www.python.org/downloads/)

**Important**: During installation, check "Add Python to PATH"

### Step 2: Install Tesseract OCR

**For Windows:**
1. Download Tesseract installer from: https://github.com/UB-Mannheim/tesseract/wiki
2. Install Tesseract (default location: `C:\Program Files\Tesseract-OCR`)
3. Add Tesseract to system PATH or update the path in the script

**For Linux:**
```bash
sudo apt-get update
sudo apt-get install tesseract-ocr
```

### Step 3: Install Python Dependencies

Open Command Prompt (Windows) or Terminal (Linux) and run:

```bash
cd path/to/extracted/files
pip install -r requirements.txt
```

Or install packages individually:

```bash
pip install opencv-python numpy Pillow pytesseract
```

## Usage

### Option 1: Basic Command-Line Version

Simple extraction with debug images:

```bash
python value_extractor.py
```

This will:
- Capture the screen
- Detect green value boxes
- Extract numerical values
- Save results to CSV
- Generate debug images

### Option 2: Optimized MCS Version (Recommended)

Specifically designed for the MCS measurement system:

```bash
python mcs_value_extractor.py
```

**Features:**
- Pre-configured for 5 measurement values
- Enhanced preprocessing for better accuracy
- Automatic labeling (Top Value, Value 2, etc.)
- Saves to both CSV and JSON formats

**For continuous monitoring:**

Edit `mcs_value_extractor.py` and uncomment the continuous monitoring section:

```python
# Uncomment these lines at the end of main()
extractor.continuous_monitoring(interval=5, duration=30)
extractor.save_results_to_csv('continuous_measurements.csv')
```

### Option 3: GUI Application

Launch the graphical interface:

```bash
python value_extractor_gui.py
```

**GUI Features:**
- 📷 **Capture Once**: Single screenshot extraction
- ▶ **Start Monitoring**: Continuous real-time monitoring
- 💾 **Save to CSV**: Export all captured data
- 🗑 **Clear History**: Reset the capture history
- **Adjustable interval**: Set monitoring frequency (1-60 seconds)

## Configuration

### Setting Tesseract Path (Windows)

If Tesseract is not in your PATH, update the script:

```python
# In mcs_value_extractor.py, line ~15
tesseract_path = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
```

### Adjusting Color Detection

If green boxes are not detected properly, adjust HSV values:

```python
# In the script's __init__ method
self.lower_green = np.array([35, 100, 100])  # Lower HSV bound
self.upper_green = np.array([85, 255, 255])  # Upper HSV bound
```

### Capture Specific Region

To capture only the application window instead of full screen:

```python
# Specify region: (x, y, width, height)
region = (100, 100, 800, 600)
results = extractor.process_screen(region=region)
```

## Output Files

### CSV Format (measurement_log.csv)
```
Timestamp,Label,Value,Raw OCR,Confidence
2025-10-15 14:30:45.123,Top Value,67.285,67.285,high
2025-10-15 14:30:45.123,Value 2,56.131,56.131,high
...
```

### JSON Format (measurement_log.json)
```json
[
  {
    "timestamp": "2025-10-15 14:30:45.123",
    "values": [
      {
        "label": "Top Value",
        "value": "67.285",
        "raw_ocr": "67.285",
        "confidence": "high"
      }
    ]
  }
]
```

### Debug Images

When debug mode is enabled, the following images are generated:

- **debug_original.png** - Original screenshot
- **debug_mask.png** - Green color detection mask
- **debug_result.png** - Annotated image with detected boxes and values
- **debug_roi_X_Y.png** - Individual region of interest crops
- **debug_thresh_X_Y.png** - Preprocessed images before OCR

## Troubleshooting

### Problem: No values detected

**Solutions:**
1. Check if Tesseract is installed correctly: `tesseract --version`
2. Adjust green color detection ranges (HSV values)
3. Enable debug mode to see what's being detected:
   ```python
   results = extractor.extract_all_values(save_debug=True)
   ```
4. Check debug_mask.png to verify green boxes are detected

### Problem: OCR reading incorrect values

**Solutions:**
1. Increase screen resolution for clearer text
2. Adjust preprocessing parameters:
   ```python
   # In extract_text_from_region method
   thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
   ```
3. Update Tesseract whitelist if needed:
   ```python
   custom_config = r'--oem 3 --psm 7 -c tessedit_char_whitelist=0123456789.'
   ```

### Problem: Application crashes

**Solutions:**
1. Ensure all dependencies are installed: `pip install -r requirements.txt`
2. Check Python version: `python --version` (should be 3.8+)
3. Verify Tesseract installation
4. Run with error handling:
   ```bash
   python mcs_value_extractor.py 2> error.log
   ```

### Problem: Values detected but extraction fails

**Solutions:**
1. The text might be too small - increase the ROI padding:
   ```python
   padding = 10  # Increase from 5
   ```
2. Check if box size filters are too restrictive:
   ```python
   if 60 < w < 200 and 20 < h < 60:  # Adjust these ranges
   ```

## Advanced Usage

### Custom Value Labels

Modify labels in `mcs_value_extractor.py`:

```python
self.value_labels = [
    "Measurement 1",
    "Measurement 2", 
    "Measurement 3",
    "Measurement 4",
    "Measurement 5"
]
```

### Integration with Other Systems

Export data for external use:

```python
import json

# Load JSON data
with open('measurement_log.json', 'r') as f:
    data = json.load(f)

# Process as needed
for entry in data:
    timestamp = entry['timestamp']
    values = entry['values']
    # Send to database, API, etc.
```

### Automated Monitoring Script

Create a batch file for automated monitoring:

**monitor.bat** (Windows):
```batch
@echo off
echo Starting MCS Measurement Monitoring...
python mcs_value_extractor.py
pause
```

**monitor.sh** (Linux):
```bash
#!/bin/bash
echo "Starting MCS Measurement Monitoring..."
python3 mcs_value_extractor.py
```

## Performance Tips

1. **Reduce capture interval** for better performance:
   ```python
   extractor.continuous_monitoring(interval=2)  # Instead of 1
   ```

2. **Disable debug mode** in production:
   ```python
   results = extractor.extract_all_values(save_debug=False)
   ```

3. **Capture specific region** instead of full screen:
   ```python
   region = (x, y, width, height)  # Application window coordinates
   ```

4. **Batch processing**: Process multiple screenshots:
   ```python
   for image_file in image_files:
       image = cv2.imread(image_file)
       # Process image...
   ```

## System Requirements

- **OS**: Windows 7/10/11, Linux, macOS
- **Python**: 3.8 or higher
- **RAM**: 2GB minimum (4GB recommended)
- **Display**: Any resolution (1920x1080 or higher recommended)
- **Tesseract OCR**: Version 4.0 or higher

## Support & Contact

For issues or questions:
1. Check the Troubleshooting section above
2. Review debug images to identify detection issues
3. Adjust parameters based on your specific display setup

## License

This software is provided as-is for measurement value extraction purposes.

## Version History

- **v1.0** - Initial release with basic extraction
- **v1.1** - Added GUI interface and continuous monitoring
- **v1.2** - Optimized for MCS measurement system with enhanced preprocessing

---

**Note**: Ensure the measurement application is visible on screen before running the extraction. Best results are achieved with clear, high-contrast displays.
