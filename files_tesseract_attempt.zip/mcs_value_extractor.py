#!/usr/bin/env python3
"""
Optimized Value Extractor for MCS Measurement System
Specifically designed for the Chinese Windows 7 measurement application
"""

import cv2
import numpy as np
from PIL import ImageGrab
import pytesseract
import re
from datetime import datetime
import json
import os


class MCSValueExtractor:
    """
    Specialized extractor for MCS measurement system
    Detects the 5 green-background measurement values
    """
    
    def __init__(self, tesseract_path=None):
        # Set tesseract path if provided (needed on Windows)
        if tesseract_path:
            pytesseract.pytesseract.tesseract_cmd = tesseract_path
        
        # Green color range in HSV (adjusted for the specific green in image)
        self.lower_green = np.array([40, 120, 120])
        self.upper_green = np.array([80, 255, 255])
        
        # Measurement labels (based on the image)
        self.value_labels = [
            "Top Value",      # 67.285
            "Value 2",        # 56.131
            "Value 3",        # 51.870
            "Value 4",        # 56.130
            "Bottom Value"    # 59.651
        ]
        
        self.results_log = []
        
    def capture_application_window(self, region=None):
        """
        Capture the measurement application window
        region: (x, y, width, height) - specify if you know the exact window location
        """
        if region:
            screenshot = ImageGrab.grab(bbox=(region[0], region[1], 
                                             region[0] + region[2], 
                                             region[1] + region[3]))
        else:
            # Full screen capture
            screenshot = ImageGrab.grab()
        
        return cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
    
    def preprocess_for_green_detection(self, image):
        """
        Preprocess image to enhance green value boxes
        """
        # Convert to HSV
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        
        # Create mask for green color
        mask = cv2.inRange(hsv, self.lower_green, self.upper_green)
        
        # Morphological operations to clean up
        kernel_close = np.ones((7, 7), np.uint8)
        kernel_open = np.ones((3, 3), np.uint8)
        
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel_close)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel_open)
        
        return mask
    
    def find_green_value_boxes(self, mask):
        """
        Find the green value boxes and sort them top to bottom
        """
        # Find contours
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        boxes = []
        for contour in contours:
            # Get bounding rectangle
            x, y, w, h = cv2.boundingRect(contour)
            
            # Filter based on expected size of value boxes
            # Adjust these thresholds based on your screen resolution
            if 60 < w < 200 and 20 < h < 60:
                area = cv2.contourArea(contour)
                if area > 500:  # Minimum area threshold
                    boxes.append({
                        'bbox': (x, y, w, h),
                        'center_y': y + h // 2,
                        'area': area
                    })
        
        # Sort by vertical position (top to bottom)
        boxes.sort(key=lambda b: b['center_y'])
        
        return boxes
    
    def extract_value_from_box(self, image, box, enhance=True):
        """
        Extract numerical value from a green box
        """
        x, y, w, h = box['bbox']
        
        # Add small padding
        padding = 3
        x = max(0, x - padding)
        y = max(0, y - padding)
        w = min(image.shape[1] - x, w + 2 * padding)
        h = min(image.shape[0] - y, h + 2 * padding)
        
        # Extract ROI
        roi = image[y:y+h, x:x+w]
        
        if enhance:
            # Convert to grayscale
            gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
            
            # Apply bilateral filter to reduce noise while keeping edges sharp
            gray = cv2.bilateralFilter(gray, 9, 75, 75)
            
            # Adaptive threshold
            thresh = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                          cv2.THRESH_BINARY, 11, 2)
            
            # Invert if needed (text should be black on white)
            if np.mean(thresh) < 127:
                thresh = cv2.bitwise_not(thresh)
        else:
            thresh = roi
        
        # OCR configuration for numbers
        # Added common OCR confusion characters
        custom_config = r'--oem 3 --psm 7 -c tessedit_char_whitelist=0123456789.'
        
        # Extract text
        text = pytesseract.image_to_string(thresh, config=custom_config)
        text = text.strip()
        
        # Clean and validate
        value = self.parse_numerical_value(text)
        
        return value, text
    
    def parse_numerical_value(self, text):
        """
        Parse and validate numerical value from OCR text
        """
        # Remove any whitespace
        text = text.replace(' ', '').replace('\n', '')
        
        # Find all number patterns
        patterns = [
            r'\d+\.\d+',  # Decimal numbers (e.g., 56.131)
            r'\d+',       # Integers
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, text)
            if matches:
                # Return the longest match (most likely to be correct)
                value = max(matches, key=len)
                try:
                    # Validate it's a reasonable measurement value
                    float_val = float(value)
                    if 0 < float_val < 1000:  # Reasonable range
                        return value
                except ValueError:
                    continue
        
        return None
    
    def extract_all_values(self, save_debug=False):
        """
        Main function to extract all measurement values
        """
        print("Capturing screen...")
        image = self.capture_application_window()
        
        if save_debug:
            cv2.imwrite('debug_original.png', image)
            print("Saved: debug_original.png")
        
        print("Detecting green value boxes...")
        mask = self.preprocess_for_green_detection(image)
        
        if save_debug:
            cv2.imwrite('debug_mask.png', mask)
            print("Saved: debug_mask.png")
        
        boxes = self.find_green_value_boxes(mask)
        
        print(f"Found {len(boxes)} potential value boxes")
        
        # Extract values
        results = []
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        
        for i, box in enumerate(boxes):
            label = self.value_labels[i] if i < len(self.value_labels) else f"Value {i+1}"
            
            value, raw_text = self.extract_value_from_box(image, box)
            
            result = {
                'label': label,
                'value': value,
                'raw_ocr': raw_text,
                'position': box['bbox'],
                'confidence': 'high' if value else 'low'
            }
            
            results.append(result)
            
            if value:
                print(f"✓ {label}: {value}")
            else:
                print(f"✗ {label}: Failed (raw: '{raw_text}')")
        
        # Save debug visualization
        if save_debug:
            debug_image = image.copy()
            for i, box in enumerate(boxes):
                x, y, w, h = box['bbox']
                cv2.rectangle(debug_image, (x, y), (x+w, y+h), (0, 255, 0), 2)
                
                # Add label
                label_text = f"{i+1}"
                if results[i]['value']:
                    label_text += f": {results[i]['value']}"
                
                cv2.putText(debug_image, label_text, (x, y-5),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
            
            cv2.imwrite('debug_result.png', debug_image)
            print("Saved: debug_result.png")
        
        # Log results
        log_entry = {
            'timestamp': timestamp,
            'values': results
        }
        self.results_log.append(log_entry)
        
        return results
    
    def save_results_to_json(self, filename='measurement_log.json'):
        """Save all results to JSON file"""
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(self.results_log, f, indent=2, ensure_ascii=False)
        print(f"\nSaved {len(self.results_log)} measurements to {filename}")
    
    def save_results_to_csv(self, filename='measurement_log.csv'):
        """Save results to CSV file"""
        import csv
        
        with open(filename, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['Timestamp', 'Label', 'Value', 'Raw OCR', 'Confidence'])
            
            for entry in self.results_log:
                timestamp = entry['timestamp']
                for result in entry['values']:
                    writer.writerow([
                        timestamp,
                        result['label'],
                        result['value'] or 'N/A',
                        result['raw_ocr'],
                        result['confidence']
                    ])
        
        print(f"Saved to {filename}")
    
    def continuous_monitoring(self, interval=5, duration=60):
        """
        Continuously monitor and extract values
        interval: seconds between captures
        duration: total monitoring duration in seconds (0 for infinite)
        """
        import time
        
        print(f"\n=== Starting Continuous Monitoring ===")
        print(f"Interval: {interval}s, Duration: {duration}s")
        print("Press Ctrl+C to stop\n")
        
        start_time = time.time()
        capture_count = 0
        
        try:
            while True:
                capture_count += 1
                print(f"\n--- Capture #{capture_count} ---")
                
                self.extract_all_values(save_debug=False)
                
                # Check duration
                if duration > 0 and (time.time() - start_time) >= duration:
                    print("\nMonitoring duration completed")
                    break
                
                # Wait for next capture
                time.sleep(interval)
                
        except KeyboardInterrupt:
            print("\n\nMonitoring stopped by user")
        
        print(f"\nTotal captures: {capture_count}")


def main():
    """
    Main function with usage examples
    """
    print("=" * 60)
    print("MCS Measurement System - Value Extractor")
    print("=" * 60)
    print()
    
    # For Windows users: Set tesseract path
    # Uncomment and modify the path below if tesseract is not in PATH
    # tesseract_path = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
    tesseract_path = None
    
    # Create extractor
    extractor = MCSValueExtractor(tesseract_path=tesseract_path)
    
    # Example 1: Single extraction with debug images
    print("Example 1: Single Extraction\n")
    results = extractor.extract_all_values(save_debug=True)
    
    # Display summary
    print("\n" + "=" * 60)
    print("EXTRACTION SUMMARY")
    print("=" * 60)
    successful = sum(1 for r in results if r['value'])
    print(f"Successfully extracted: {successful}/{len(results)} values")
    print()
    
    for result in results:
        if result['value']:
            print(f"  {result['label']:20s} = {result['value']}")
    
    # Save results
    extractor.save_results_to_csv('measurements.csv')
    extractor.save_results_to_json('measurements.json')
    
    # Example 2: Continuous monitoring (commented out)
    # print("\n" + "=" * 60)
    # print("Example 2: Continuous Monitoring")
    # print("=" * 60)
    # extractor.continuous_monitoring(interval=5, duration=30)
    # extractor.save_results_to_csv('continuous_measurements.csv')
    
    print("\n" + "=" * 60)
    print("Extraction complete!")
    print("=" * 60)


if __name__ == "__main__":
    main()
