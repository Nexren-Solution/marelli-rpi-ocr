#!/usr/bin/env python3
"""
GUI Version - Screen Value Extractor with Real-time Monitoring
"""

import cv2
import numpy as np
from PIL import ImageGrab, Image
import pytesseract
import re
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import threading
import time
import csv


class ValueExtractorGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Screen Value Extractor - Measurement System")
        self.root.geometry("900x700")
        
        # Variables
        self.monitoring = False
        self.monitor_interval = 2  # seconds
        self.extracted_values = []
        self.history = []
        
        # Color ranges for green background
        self.lower_green = np.array([35, 100, 100])
        self.upper_green = np.array([85, 255, 255])
        
        self.setup_ui()
        
    def setup_ui(self):
        """Setup the user interface"""
        
        # Title
        title_frame = tk.Frame(self.root, bg='#2c3e50', height=60)
        title_frame.pack(fill='x')
        title_frame.pack_propagate(False)
        
        tk.Label(title_frame, text="Measurement Value Extractor", 
                font=('Arial', 18, 'bold'), bg='#2c3e50', fg='white').pack(pady=15)
        
        # Control Panel
        control_frame = ttk.LabelFrame(self.root, text="Controls", padding=10)
        control_frame.pack(fill='x', padx=10, pady=5)
        
        # Buttons
        btn_frame = tk.Frame(control_frame)
        btn_frame.pack(fill='x')
        
        self.capture_btn = ttk.Button(btn_frame, text="📷 Capture Once", 
                                      command=self.capture_once, width=20)
        self.capture_btn.pack(side='left', padx=5)
        
        self.monitor_btn = ttk.Button(btn_frame, text="▶ Start Monitoring", 
                                      command=self.toggle_monitoring, width=20)
        self.monitor_btn.pack(side='left', padx=5)
        
        ttk.Button(btn_frame, text="💾 Save to CSV", 
                  command=self.save_to_csv, width=20).pack(side='left', padx=5)
        
        ttk.Button(btn_frame, text="🗑 Clear History", 
                  command=self.clear_history, width=15).pack(side='left', padx=5)
        
        # Settings
        settings_frame = tk.Frame(control_frame)
        settings_frame.pack(fill='x', pady=5)
        
        tk.Label(settings_frame, text="Monitor Interval (sec):").pack(side='left', padx=5)
        self.interval_var = tk.StringVar(value="2")
        interval_spinbox = ttk.Spinbox(settings_frame, from_=1, to=60, 
                                       textvariable=self.interval_var, width=10)
        interval_spinbox.pack(side='left', padx=5)
        
        # Region selection
        tk.Label(settings_frame, text="Screen Region:").pack(side='left', padx=20)
        self.region_var = tk.StringVar(value="Full Screen")
        region_combo = ttk.Combobox(settings_frame, textvariable=self.region_var, 
                                    values=["Full Screen", "Custom Region"], 
                                    state='readonly', width=15)
        region_combo.pack(side='left', padx=5)
        
        # Status
        status_frame = tk.Frame(control_frame)
        status_frame.pack(fill='x', pady=5)
        
        tk.Label(status_frame, text="Status:").pack(side='left')
        self.status_label = tk.Label(status_frame, text="Ready", 
                                     fg='green', font=('Arial', 10, 'bold'))
        self.status_label.pack(side='left', padx=5)
        
        # Current Values Display
        values_frame = ttk.LabelFrame(self.root, text="Current Values", padding=10)
        values_frame.pack(fill='both', expand=True, padx=10, pady=5)
        
        # Create treeview for current values
        columns = ('Index', 'Value', 'Time')
        self.values_tree = ttk.Treeview(values_frame, columns=columns, 
                                       show='headings', height=6)
        
        self.values_tree.heading('Index', text='Position')
        self.values_tree.heading('Value', text='Value')
        self.values_tree.heading('Time', text='Timestamp')
        
        self.values_tree.column('Index', width=100, anchor='center')
        self.values_tree.column('Value', width=150, anchor='center')
        self.values_tree.column('Time', width=200, anchor='center')
        
        values_scrollbar = ttk.Scrollbar(values_frame, orient='vertical', 
                                        command=self.values_tree.yview)
        self.values_tree.configure(yscrollcommand=values_scrollbar.set)
        
        self.values_tree.pack(side='left', fill='both', expand=True)
        values_scrollbar.pack(side='right', fill='y')
        
        # History Display
        history_frame = ttk.LabelFrame(self.root, text="History Log", padding=10)
        history_frame.pack(fill='both', expand=True, padx=10, pady=5)
        
        # Create treeview for history
        hist_columns = ('Time', 'Count', 'Values')
        self.history_tree = ttk.Treeview(history_frame, columns=hist_columns, 
                                        show='headings', height=8)
        
        self.history_tree.heading('Time', text='Timestamp')
        self.history_tree.heading('Count', text='Count')
        self.history_tree.heading('Values', text='Extracted Values')
        
        self.history_tree.column('Time', width=200, anchor='center')
        self.history_tree.column('Count', width=80, anchor='center')
        self.history_tree.column('Values', width=500, anchor='w')
        
        hist_scrollbar = ttk.Scrollbar(history_frame, orient='vertical', 
                                      command=self.history_tree.yview)
        self.history_tree.configure(yscrollcommand=hist_scrollbar.set)
        
        self.history_tree.pack(side='left', fill='both', expand=True)
        hist_scrollbar.pack(side='right', fill='y')
        
    def capture_screen(self, region=None):
        """Capture screenshot"""
        if region:
            screenshot = ImageGrab.grab(bbox=region)
        else:
            screenshot = ImageGrab.grab()
        return cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
    
    def detect_green_regions(self, image):
        """Detect regions with green background"""
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, self.lower_green, self.upper_green)
        
        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        
        return mask
    
    def find_value_boxes(self, image, mask):
        """Find bounding boxes around green regions"""
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        boxes = []
        for contour in contours:
            x, y, w, h = cv2.boundingRect(contour)
            
            # Filter by size
            if w > 50 and h > 15 and w < 300 and h < 80:
                boxes.append((x, y, w, h))
        
        boxes.sort(key=lambda b: b[1])
        return boxes
    
    def extract_text_from_region(self, image, box):
        """Extract text from a specific region using OCR"""
        x, y, w, h = box
        
        padding = 5
        x = max(0, x - padding)
        y = max(0, y - padding)
        w = w + 2 * padding
        h = h + 2 * padding
        
        roi = image[y:y+h, x:x+w]
        gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
        _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
        thresh = cv2.bitwise_not(thresh)
        
        custom_config = r'--oem 3 --psm 7 -c tessedit_char_whitelist=0123456789.'
        text = pytesseract.image_to_string(thresh, config=custom_config)
        
        return text.strip()
    
    def extract_numerical_value(self, text):
        """Extract numerical value from text string"""
        matches = re.findall(r'\d+\.?\d*', text)
        if matches:
            return max(matches, key=len)
        return None
    
    def process_extraction(self):
        """Main extraction process"""
        try:
            self.status_label.config(text="Processing...", fg='orange')
            self.root.update()
            
            # Capture screen
            image = self.capture_screen()
            
            # Detect and extract
            mask = self.detect_green_regions(image)
            boxes = self.find_value_boxes(image, mask)
            
            results = []
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            for i, box in enumerate(boxes):
                text = self.extract_text_from_region(image, box)
                value = self.extract_numerical_value(text)
                
                if value:
                    results.append({
                        'index': i + 1,
                        'value': value,
                        'timestamp': timestamp
                    })
            
            self.extracted_values = results
            self.update_display(results, timestamp)
            
            self.status_label.config(text=f"Extracted {len(results)} values", fg='green')
            
            return results
            
        except Exception as e:
            self.status_label.config(text=f"Error: {str(e)}", fg='red')
            messagebox.showerror("Error", f"Extraction failed: {str(e)}")
            return []
    
    def update_display(self, results, timestamp):
        """Update the display with new results"""
        # Clear current values tree
        for item in self.values_tree.get_children():
            self.values_tree.delete(item)
        
        # Add new values
        for result in results:
            self.values_tree.insert('', 'end', values=(
                f"Position {result['index']}",
                result['value'],
                result['timestamp']
            ))
        
        # Add to history
        if results:
            values_str = ", ".join([r['value'] for r in results])
            self.history_tree.insert('', 0, values=(
                timestamp,
                len(results),
                values_str
            ))
            
            # Keep history limited
            children = self.history_tree.get_children()
            if len(children) > 100:
                self.history_tree.delete(children[-1])
            
            self.history.append({
                'timestamp': timestamp,
                'values': results
            })
    
    def capture_once(self):
        """Capture and extract once"""
        self.process_extraction()
    
    def toggle_monitoring(self):
        """Start/stop continuous monitoring"""
        if not self.monitoring:
            self.monitoring = True
            self.monitor_btn.config(text="⏸ Stop Monitoring")
            self.capture_btn.config(state='disabled')
            threading.Thread(target=self.monitor_loop, daemon=True).start()
        else:
            self.monitoring = False
            self.monitor_btn.config(text="▶ Start Monitoring")
            self.capture_btn.config(state='normal')
    
    def monitor_loop(self):
        """Continuous monitoring loop"""
        while self.monitoring:
            self.process_extraction()
            
            try:
                interval = float(self.interval_var.get())
            except:
                interval = 2
            
            time.sleep(interval)
    
    def save_to_csv(self):
        """Save history to CSV file"""
        if not self.history:
            messagebox.showwarning("No Data", "No data to save!")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
            initialfile=f"measurements_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        )
        
        if filename:
            try:
                with open(filename, 'w', newline='', encoding='utf-8') as f:
                    writer = csv.writer(f)
                    writer.writerow(['Timestamp', 'Position', 'Value'])
                    
                    for entry in self.history:
                        timestamp = entry['timestamp']
                        for result in entry['values']:
                            writer.writerow([
                                timestamp,
                                f"Position {result['index']}",
                                result['value']
                            ])
                
                messagebox.showinfo("Success", f"Data saved to {filename}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save: {str(e)}")
    
    def clear_history(self):
        """Clear all history"""
        if messagebox.askyesno("Confirm", "Clear all history?"):
            self.history = []
            for item in self.history_tree.get_children():
                self.history_tree.delete(item)
            self.status_label.config(text="History cleared", fg='green')


def main():
    root = tk.Tk()
    app = ValueExtractorGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
