@echo off
title MCS Measurement Value Extractor
color 0A

echo ========================================
echo  MCS Measurement Value Extractor
echo ========================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not installed or not in PATH
    echo Please install Python from https://www.python.org/
    pause
    exit /b 1
)

echo [OK] Python is installed
echo.

REM Check if dependencies are installed
echo Checking dependencies...
python -c "import cv2, numpy, PIL, pytesseract" >nul 2>&1
if errorlevel 1 (
    echo [WARNING] Some dependencies are missing
    echo Installing required packages...
    pip install -r requirements.txt
    if errorlevel 1 (
        echo [ERROR] Failed to install dependencies
        pause
        exit /b 1
    )
)

echo [OK] All dependencies are installed
echo.

REM Main menu
:menu
echo ========================================
echo  Select Operation Mode:
echo ========================================
echo.
echo  1. Single Capture (Basic Version)
echo  2. MCS Optimized Extraction
echo  3. Launch GUI Application
echo  4. Continuous Monitoring (30 seconds)
echo  5. Install/Update Dependencies
echo  6. Exit
echo.
set /p choice="Enter your choice (1-6): "

if "%choice%"=="1" goto basic
if "%choice%"=="2" goto mcs
if "%choice%"=="3" goto gui
if "%choice%"=="4" goto monitor
if "%choice%"=="5" goto install
if "%choice%"=="6" goto end

echo Invalid choice! Please try again.
echo.
goto menu

:basic
echo.
echo Running basic value extractor...
echo.
python value_extractor.py
echo.
pause
goto menu

:mcs
echo.
echo Running MCS optimized extractor...
echo.
python mcs_value_extractor.py
echo.
pause
goto menu

:gui
echo.
echo Launching GUI application...
echo.
start pythonw value_extractor_gui.py
echo GUI launched in separate window
echo.
pause
goto menu

:monitor
echo.
echo Starting continuous monitoring (30 seconds)...
echo Press Ctrl+C to stop early
echo.
python -c "from mcs_value_extractor import MCSValueExtractor; e = MCSValueExtractor(); e.continuous_monitoring(interval=5, duration=30); e.save_results_to_csv('continuous_measurements.csv')"
echo.
echo Monitoring complete! Results saved to continuous_measurements.csv
pause
goto menu

:install
echo.
echo Installing/Updating dependencies...
echo.
pip install --upgrade -r requirements.txt
echo.
echo Dependencies updated!
pause
goto menu

:end
echo.
echo Thank you for using MCS Value Extractor!
echo.
pause
exit
