#!/usr/bin/env python3
"""
Screen Value Extractor for Measurement System
Detects and extracts green background values with black text
"""

import cv2
import numpy as np
from PIL import ImageGrab, Image
import pytesseract
import re
from datetime import datetime
import os

class ValueExtractor:
    def __init__(self):
        # Define color range for green background (HSV)
        self.lower_green = np.array([35, 100, 100])
        self.upper_green = np.array([85, 255, 255])
        
        # Results storage
        self.extracted_values = []
        
    def capture_screen(self, region=None):
        """
        Capture screenshot
        region: tuple (x, y, width, height) or None for full screen
        """
        if region:
            screenshot = ImageGrab.grab(bbox=region)
        else:
            screenshot = ImageGrab.grab()
        return cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
    
    def detect_green_regions(self, image):
        """
        Detect regions with green background
        """
        # Convert to HSV color space
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        
        # Create mask for green color
        mask = cv2.inRange(hsv, self.lower_green, self.upper_green)
        
        # Apply morphological operations to clean up the mask
        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        
        return mask
    
    def find_value_boxes(self, image, mask):
        """
        Find bounding boxes around green regions
        """
        # Find contours
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        boxes = []
        for contour in contours:
            # Get bounding rectangle
            x, y, w, h = cv2.boundingRect(contour)
            
            # Filter by size (adjust these values based on your display)
            if w > 50 and h > 15 and w < 300 and h < 80:
                boxes.append((x, y, w, h))
        
        # Sort boxes by y-coordinate (top to bottom)
        boxes.sort(key=lambda b: b[1])
        
        return boxes
    
    def extract_text_from_region(self, image, box, debug=False):
        """
        Extract text from a specific region using OCR
        """
        x, y, w, h = box
        
        # Add padding
        padding = 5
        x = max(0, x - padding)
        y = max(0, y - padding)
        w = w + 2 * padding
        h = h + 2 * padding
        
        # Crop region
        roi = image[y:y+h, x:x+w]
        
        if debug:
            cv2.imwrite(f'debug_roi_{x}_{y}.png', roi)
        
        # Convert to grayscale
        gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
        
        # Apply thresholding to get black text on white background
        _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
        
        # Invert so text is black on white
        thresh = cv2.bitwise_not(thresh)
        
        if debug:
            cv2.imwrite(f'debug_thresh_{x}_{y}.png', thresh)
        
        # Use pytesseract to extract text
        # Configure for digits and decimal point
        custom_config = r'--oem 3 --psm 7 -c tessedit_char_whitelist=0123456789.'
        text = pytesseract.image_to_string(thresh, config=custom_config)
        
        # Clean up the text
        text = text.strip()
        
        return text
    
    def extract_numerical_value(self, text):
        """
        Extract numerical value from text string
        """
        # Find all numbers (including decimals)
        matches = re.findall(r'\d+\.?\d*', text)
        
        if matches:
            # Return the first (or longest) match
            return max(matches, key=len)
        return None
    
    def process_screen(self, region=None, debug=False):
        """
        Main processing function
        """
        # Capture screen
        image = self.capture_screen(region)
        
        if debug:
            cv2.imwrite('debug_original.png', image)
        
        # Detect green regions
        mask = self.detect_green_regions(image)
        
        if debug:
            cv2.imwrite('debug_mask.png', mask)
        
        # Find value boxes
        boxes = self.find_value_boxes(image, mask)
        
        print(f"Found {len(boxes)} green value boxes")
        
        # Extract values
        results = []
        for i, box in enumerate(boxes):
            text = self.extract_text_from_region(image, box, debug)
            value = self.extract_numerical_value(text)
            
            if value:
                results.append({
                    'index': i,
                    'value': value,
                    'position': box,
                    'raw_text': text,
                    'timestamp': datetime.now().isoformat()
                })
                print(f"Value {i+1}: {value}")
            else:
                print(f"Value {i+1}: Could not extract (raw: '{text}')")
        
        # Draw boxes on image for visualization
        if debug:
            result_image = image.copy()
            for i, box in enumerate(boxes):
                x, y, w, h = box
                cv2.rectangle(result_image, (x, y), (x+w, y+h), (0, 255, 0), 2)
                cv2.putText(result_image, f"{i+1}", (x, y-5), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
            cv2.imwrite('debug_result.png', result_image)
        
        self.extracted_values = results
        return results
    
    def save_to_csv(self, filename='extracted_values.csv'):
        """
        Save extracted values to CSV file
        """
        import csv
        
        if not self.extracted_values:
            print("No values to save")
            return
        
        with open(filename, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=['timestamp', 'index', 'value', 'position'])
            writer.writeheader()
            
            for item in self.extracted_values:
                writer.writerow({
                    'timestamp': item['timestamp'],
                    'index': item['index'],
                    'value': item['value'],
                    'position': str(item['position'])
                })
        
        print(f"Saved {len(self.extracted_values)} values to {filename}")


def main():
    """
    Main function with example usage
    """
    print("=== Screen Value Extractor ===\n")
    
    # Create extractor instance
    extractor = ValueExtractor()
    
    # Option 1: Capture full screen
    print("Capturing screen and extracting values...\n")
    results = extractor.process_screen(debug=True)
    
    # Option 2: Capture specific region (uncomment and adjust coordinates)
    # region = (100, 100, 800, 600)  # (x, y, width, height)
    # results = extractor.process_screen(region=region, debug=True)
    
    # Display results
    print("\n=== Extracted Values ===")
    for result in results:
        print(f"Position {result['index']+1}: {result['value']}")
    
    # Save to CSV
    extractor.save_to_csv('measurement_values.csv')
    
    print("\nDebug images saved (check current directory)")


if __name__ == "__main__":
    main()
